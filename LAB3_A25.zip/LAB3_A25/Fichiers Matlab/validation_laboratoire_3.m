%%% Initialisation
clc;
clear;
close all;

%%% Organisation des repertoires
addpath('Aircraft/', 'Modules/');
thisFileDir = fileparts(mfilename('fullpath'));
addpath(fullfile(thisFileDir, 'Aircraft'));
addpath(fullfile(thisFileDir, 'Modules'));
%% % Debut de vos etudes
avion = f_loadAircraftData;

%% % Validation de la partie A
% Conditions de vol pour validation
tas_mps = m_convert.f_velocity(240, 'kts' , 'm/s');
altitude_m = m_convert.f_length(20000, 'ft' , 'm');
qbar_pa = m_atmos.f_pression_dynamique(tas_mps, altitude_m);
alpha_rad = m_convert.f_angle(5, 'deg', 'rad');
mach_nb = m_atmos.f_nombre_mach(tas_mps, altitude_m);
fn_n = m_convert.f_force(15000, 'lbf', 'N');
masse_kg = m_convert.f_mass(100000, 'lbm', 'kg');
theta_rad = m_convert.f_angle(5, 'deg', 'rad');
xcg_perc = 0.1;
zcg_m = 0;
alpha_dot = 0;
q_radps = 0;
delta_e = 0;
delev_rad = 0;
dflaps = 0;
dstab_rad = 0;

%%% Coefficients dans le repère stabilité
[cls, cds, cms] = m_aero.f_coeff_stabilite(alpha_rad, alpha_dot, ...
    q_radps, tas_mps, mach_nb, qbar_pa, delev_rad, dflaps, dstab_rad, ...
    fn_n, avion);

%%% Coefficients dans le repère body
[clb, cdb, cmb] = m_aero.f_stab2body(cls, cds, cms, alpha_rad)

%%% Forces et moment
[fx_n, fz_n, my_nm] = m_edm.f_forces(clb, cdb, cmb, theta_rad, xcg_perc, ...
    zcg_m, masse_kg, qbar_pa, fn_n, avion)


    
% % Partie B
%% Configuration de l'avion (centrage)
conditions.masse_kg  = m_convert.f_mass(130000, 'lbm', 'kg');
conditions.Iyy_kgm2  = avion.inertie.Iyy_kgm2;
conditions.xcg_perc  = 0;
conditions.zcg_m     = 0;

%% Définition de la condition de vol
conditions.tas_mps   = m_convert.f_velocity(250, 'kts', 'm/s');
conditions.altitude_m= m_convert.f_length(20000, 'ft', 'm');

%% Configuration des volets (position croisière) et des surfaces de contrôle
conditions.dflaps    = 0;
conditions.dstab_rad = m_convert.f_angle(-6.6171, 'deg', 'rad');
conditions.delev_rad = m_convert.f_angle(-0.5905, 'deg', 'rad');

%% Définition des paramètres de vol
conditions.q_radps   = 0;
alpha_dot = 0;
conditions.alpha_rad = m_convert.f_angle(7.4108, 'deg', 'rad');
conditions.theta_rad = conditions.alpha_rad;   % vol symétrique: θ ≈ α en palier

%% Configuration des moteurs
conditions.fn_n      = 3.3320e+04;   % [N]

mach_nb = m_atmos.f_nombre_mach(conditions.tas_mps, conditions.altitude_m);
qbar_pa = m_atmos.f_pression_dynamique(conditions.tas_mps, conditions.altitude_m);
%%% Coefficients dans le repère stabilité


ub0   = conditions.tas_mps * cos(conditions.alpha_rad);
wb0   = conditions.tas_mps * sin(conditions.alpha_rad);
q0    = conditions.q_radps;        % = 0 à l’init (page 10)
theta0= conditions.theta_rad;      % = alpha_rad à l’init (palier)
h0    = conditions.altitude_m;

x0 = [ub0; wb0; q0; theta0; h0];

[time, x] = m_edm.f_simuler_avion(x0, 50, 1.0, conditions, avion, []);

% time = t;  x = X;

% Affichage du résultat de la simulation
figure;
subplot(3, 2, [1 2]);
plot(time, m_convert.f_length(x(:, 5), 'm', 'ft')); grid on; box on;
xlabel('Temps [sec]'); ylabel('Altitude [ft]');
set(gca, 'XMinorGrid', 'on', 'YMinorGrid', 'on', 'Xlim', [0 50], ...
         'Ylim', [15000 25000]);

subplot(3, 2, 3);
plot(time, m_convert.f_velocity(x(:, 1), 'm/s', 'kts')); grid on; box on;
set(gca, 'XMinorGrid', 'on', 'YMinorGrid', 'on', 'Xlim', [0 50], ...
         'Ylim', [200 300]);
ylabel('u_b [kts]');

subplot(3, 2, 4);
plot(time, m_convert.f_velocity(x(:, 2), 'm/s', 'kts')); grid on; box on;
set(gca, 'XMinorGrid', 'on', 'YMinorGrid', 'on', 'Xlim', [0 50], ...
         'Ylim', [20 40]);
ylabel('w_b [kts]');

subplot(3, 2, 5);
plot(time, m_convert.f_angle(x(:, 3), 'rad', 'deg')); grid on; box on;
set(gca, 'XMinorGrid', 'on', 'YMinorGrid', 'on', 'Xlim', [0 50], ...
         'Ylim', [-5 5]);
xlabel('Temps [sec]'); ylabel('q [deg/s]');

subplot(3, 2, 6);
plot(time, m_convert.f_angle(x(:, 4), 'rad', 'deg')); grid on; box on;
set(gca, 'XMinorGrid', 'on', 'YMinorGrid', 'on', 'Xlim', [0 50], ...
         'Ylim', [0 10]);
xlabel('Temps [sec]'); ylabel('\theta [deg]');